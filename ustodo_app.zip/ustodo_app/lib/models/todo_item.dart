class TodoItem {
  final String id;
  final String title;
  final DateTime createdAt;
  final DateTime dueAt;
  bool isDone;

  TodoItem({
    required this.id,
    required this.title,
    required this.dueAt,
    DateTime? createdAt,
    this.isDone = false,
  }) : createdAt = createdAt ?? DateTime.now();
}
